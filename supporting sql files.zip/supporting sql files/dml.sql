INSERT INTO `admin` (`adminid`, `username`, `fullname`, `adminemail`, `password`, `pic`) VALUES
(1, 'admin', 'Admin jones', 'admin@gmail.com', 'admin', 'user2.png');
INSERT INTO `authors` (`authorid`, `authorname`) VALUES
(9, 'Bjarne Stroustrup'),
(11, 'Anthony Brun'),
(14, 'E. Balagurusamy'),
(15, 'Ken Liu'),
(16, 'A.G Riddle'),
(17, 'Rakib Hassan'),
(18, 'Rob Boffard'),
(19, 'Khaled Hosseini'),
(20, 'Sandra Block'),
(21, 'J.R.R. Tolkien'),
(22, 'William Goldman'),
(24, 'Md. Zafar Iqbal Hassan'),
(29, 'James Patterson');
INSERT INTO `books` (`bookid`, `bookpic`, `bookname`, `authorid`, `categoryid`, `ISBN`, `price`, `quantity`, `status`) VALUES
(20, 'cplus.jpg', 'Java', 11, 2, '27899', 200, 9, 'Available'),
(22, 'python2.jpg', 'Python Programming', 11, 2, '2456', 600, 5, 'Available'),
(28, 'c.jpg', 'C Programming ', 14, 2, '24512', 200, 8, 'Available'),
(29, 'sf1.jpg', 'Basics of Python', 15, 1, '2123', 3200, 6, 'Available'),
(30, 'sf2.jpg', 'Hello World', 16, 1, '278999', 210, 6, 'Available'),
(31, 'sf3.jpg', 'World of Computer', 17, 1, '254789', 200, 9, 'Available'),
(32, 'sf4.jpg', 'Adrift', 18, 1, '24569', 500, 8, 'Available'),
(33, 'nv1.jpg', 'Basics of C Programming', 19, 3, '23658', 100, 8, 'Available'),
(34, 'nv2.jpg', 'Basics of C Programming', 20, 3, '21569', 100, 7, 'Available'),
(35, 'nv3.jpg', 'Lets C', 21, 3, '21569', 100, 8, 'Available'),
(36, 'nv4.jpg', 'Basics of C#', 22, 3, '21456', 200, 5, 'Available'),
(40, 'java.jpg', 'Java', 29, 2, '24512', 500, 8, 'Available');
INSERT INTO `category` (`categoryid`, `categoryname`) VALUES
(1, 'Science FIction'),
(2, 'Computer Programming'),
(3, 'Novel'),
(4, 'History');
INSERT INTO `feedback` (`stdid`, `rating`, `comment`, `date`) VALUES
(1, 5, 'I just love it', '2021-04-23'),
(3, 4, 'I just like it', '2021-04-23'),
(4, 3, 'It is awesome. Overall good', '2021-04-23'),
(1, 2, 'I dont like it', '2021-04-23');
INSERT INTO `issueinfo` (`studentid`, `bookid`, `issuedate`, `returndate`, `approve`, `fine`) VALUES
(3, 20, '0000-00-00', '0000-00-00', '', 0),
(1, 22, '2021-04-19', '2021-04-21', '<p style=\"color:yellow; background-color:red;\">EXPIRED</p>', 20),
(23, 29, '2024-06-28', '2024-06-30', '', 0),
(23, 35, '0000-00-00', '0000-00-00', '', 0);
INSERT INTO `message` (`id`, `username`, `message`, `status`, `sender`, `date`) VALUES
(2, 'John12', 'hello', 'yes', 'student', '04/20/2021 Tuesday, 05:08 PM'),
(3, 'John12', 'how are you??', 'yes', 'student', '04/20/2021 Tuesday, 05:08 PM'),
(4, 'John12', 'I need a book. Can you help me??', 'yes', 'student', '04/23/2021 Friday, 12:27 PM'),
(5, 'John12', 'Hello', 'no', 'admin', '04/23/2021 Friday, 12:58 PM'),
(6, 'John12', 'hello', 'yes', 'student', '04/23/2021 Friday, 01:00 PM'),
(7, 'John12', 'how are you', 'no', 'admin', '04/23/2021 Friday, 02:00 PM'),
(8, 'John12', 'hello', 'yes', 'admin', '04/23/2021 Friday, 02:00 PM'),
(9, 'John12', 'hello', 'yes', 'student', '04/23/2021 Friday, 02:01 PM'),
(10, 'John12', 'how are you', 'yes', 'admin', '04/23/2021 Friday, 06:13 PM'),
(11, 'John12', 'hello i need a book', 'yes', 'student', '04/23/2021 Friday, 07:02 PM'),
(12, 'John12', 'hello', 'no', 'admin', '04/23/2021 Friday, 07:24 PM');
INSERT INTO `student` (`studentid`, `student_username`, `FullName`, `Email`, `Password`, `PhoneNumber`, `studentpic`) VALUES
(1, 'John ', 'John Doe', 'john@gmail.com', '12', '12354234', 'user.jpg'),
(3, 'Jane', 'Jane Smith', 'jane@gmail.com', '123456', '029283718\r\n', 'user.jpg'),
(4, 'Alice', 'Alice Johnson', 'alice@gmail.com', '123456', '665352562', 'user.jpg'),
(23, 'sam', 'sam', 'sam@gmail.com', 'samjones', '9875556123', 'user.gif');
INSERT INTO `timer` (`stdid`, `bid`, `date`) VALUES
(1, 22, '2021-04-21 23:22:00'),
(23, 29, '2024-06-28 18:24:00');
INSERT INTO `trendingbook` (`bookid`) VALUES
(22),
(20),
(33),
(28);