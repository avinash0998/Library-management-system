-- Queries to implement narrative tasks

-- Task 1: List all books along with their authors and categories.
SELECT books.bookname, authors.authorname, category.categoryname
FROM books
JOIN authors ON books.authorid = authors.authorid
JOIN category ON books.categoryid = category.categoryid;

-- Task 2: Show all students who have issued books.
SELECT student.FullName, books.bookname, issueinfo.issuedate
FROM issueinfo
JOIN student ON issueinfo.studentid = student.studentid
JOIN books ON issueinfo.bookid = books.bookid;

-- Task 3: List all feedback given by students.
SELECT student.FullName, feedback.rating, feedback.comment, feedback.date
FROM feedback
JOIN student ON feedback.stdid = student.studentid;

-- Task 4: List messages sent by students or admin.
SELECT message.username, message.message, message.status, message.sender, message.date
FROM message
WHERE message.sender = 'student' OR message.sender = 'admin';

-- Task 5: List all books that are available.
SELECT bookname FROM books WHERE status = 'Available';
