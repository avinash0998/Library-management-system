-- Complex reports

-- Report 1: Books along with their authors and category with aggregate function
SELECT books.bookname, authors.authorname, category.categoryname, COUNT(*) as total_books
FROM books
JOIN authors ON books.authorid = authors.authorid
JOIN category ON books.categoryid = category.categoryid
GROUP BY books.bookname, authors.authorname, category.categoryname;


-- Purpose: This report aims to provide a comprehensive list of books along with their respective authors and categories, while also counting the total number of books in each combination of book, author, and category.

-- Justification of Complexity: This query involves joining three tables (books, authors, and category) to gather information from different entities. It uses an aggregate function (COUNT(*)) to calculate the total number of books for each unique combination of book, author, and category. This complexity is justified as it provides detailed information with aggregation, catering to scenarios where a consolidated view of books by author and category is needed.
-- Report 2: Students and the count of books they have issued
SELECT student.FullName, COUNT(issueinfo.bookid) as total_issued_books
FROM issueinfo
JOIN student ON issueinfo.studentid = student.studentid
GROUP BY student.FullName;

-- Purpose: This report aims to list all students along with the total count of books each student has issued.
-- Justification of Complexity: It involves joining the issueinfo table with the student table to link issued books with their respective students. The COUNT(issueinfo.bookid) function is used to aggregate the number of books issued by each student. This query is moderately complex due to the need for accurate aggregation by student, which is crucial for tracking student activity and managing library resources efficiently.


-- Report 3: Feedback summary by rating
SELECT rating, COUNT(*) as total_feedback
FROM feedback
GROUP BY rating;

-- Purpose: This report provides a summary of feedback ratings received, showing the count of feedback entries for each rating.
-- Justification of Complexity: It uses a simple GROUP BY clause to aggregate feedback entries based on their ratings. Despite its simplicity in syntax, it provides valuable insights into customer satisfaction or dissatisfaction based on feedback ratings. This query is straightforward yet essential for understanding customer sentiment and improving services based on feedback analysis.


-- Report 4: Monthly issued books
SELECT MONTH(issuedate) as month, COUNT(*) as total_issued_books
FROM issueinfo
GROUP BY MONTH(issuedate);

-- Purpose: This report aims to analyze the monthly trend of issued books, showing the total number of books issued each month.
-- Justification of Complexity: It utilizes the MONTH() function to extract the month from the issuedate column and then aggregates the count of issued books for each month. This query is crucial for monitoring and planning library operations based on seasonal trends in book issuance. Its complexity lies in the date manipulation and aggregation functions used, which are essential for temporal analysis.




-- Report 5: Books with the highest quantity
SELECT bookname, quantity
FROM books
ORDER BY quantity DESC
LIMIT 5;

-- Purpose: This report identifies the top 5 books with the highest quantity available in the library.
-- Justification of Complexity: It uses a simple ORDER BY clause with DESC to sort books by quantity in descending order and limits the results to the top 5. Although straightforward in syntax, this query provides valuable information for inventory management and ensuring popular books are adequately stocked. Its justification lies in its direct relevance to operational efficiency and user satisfaction, despite its relative simplicity compared to other reports.

