## How to run

Open the sql file in the xammp server by creating the database.
Run it on localhost of the brower with the http://localhost:3000/index.php
Admin login details: 
Username: admin
Password: admin